<?php
namespace App;

use Illuminate\Database\Eloquent\Model;


class InfoPropietario extends Model
{
    protected $table='info_propietario';
}